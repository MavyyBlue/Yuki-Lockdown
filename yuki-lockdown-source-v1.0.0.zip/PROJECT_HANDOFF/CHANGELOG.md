# Changelog

## 1.0.0 — 2026-09-29, phone-test candidate
- Native five-area Android interface and approved Yuki asset integration.
- Deterministic policy, daily usage reconstruction, profile schedules, exemptions and domain matching.
- Accessibility intervention, AI redirect, persistent reactions, owner bypass and optional warnings.
- SQLite configuration, corruption fail-open behavior, reboot/time-change receivers and diagnostics.
- Java policy tests, device persistence tests, safe mobile bootstrap installer and test suite.
- Recovered source from saved checkpoint after transient workspace removal; restored fixes and packaging.
- Exact recovered build awaits GitHub validation and real-device acceptance; historical candidate build evidence is explicitly distinguished.
